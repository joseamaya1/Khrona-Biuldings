##### CREDITS #####
Version 1.0.3 for TFS 1.0, first version
Acc. script:
*Gesior - e-mail: phoowned@wp.pl
Layouts:
*CipSoft Gmbh - www.tibia.com