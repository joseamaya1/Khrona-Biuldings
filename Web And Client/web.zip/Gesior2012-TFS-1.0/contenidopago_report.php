<?php
$_GET['subtopic'] = 'contenidopago_report';
$_REQUEST['subtopic'] = 'contenidopago_report';
include('index.php');