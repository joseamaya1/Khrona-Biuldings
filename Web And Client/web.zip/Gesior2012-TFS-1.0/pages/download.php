<?php
if(!defined('INITIALIZED'))
	exit;

$main_content .= 'Edit this text in pages/download.php.';