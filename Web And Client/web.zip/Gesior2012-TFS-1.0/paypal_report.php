<?php
$_GET['subtopic'] = 'paypal_report';
$_REQUEST['subtopic'] = 'paypal_report';
include('index.php');